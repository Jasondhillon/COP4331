
public class Project3
{

	public static void main(String[] args)
	{
		new GUI();

	}

}
